package Homework.Ashley;

public class Calendar {

        private static final int MAXEVENTS = 4;
        private int numEvents;
        private Event[] events;

    public Calendar() {
            events = new Event[MAXEVENTS];
            numEvents = 0;

        }

        public boolean addEvent (Event e){
            //true if add false if not
            // traverse array and insert the event into the first null entry.
            //increment numEvents

            //returns false if full
            if (numEvents >= MAXEVENTS) {
                return false;
            }

            //check for null
            int i = 0;
            for (; i < events.length; i++) {
                if (events[i] == null) {
                    break;
                }
            }

            //successful add
            events[i] = e;
            numEvents += 1;
            return true;

        }

        public int findEvent (Event e){
            // look for equal to e, check if null as well.
            //nothing found in index then return -1;

            int i = 0;
            for (; i < events.length; i++) {
                if (events[i] != null && events[i].equals(e)) {
                    return i;
                }
            }

            return -1;

        }

        public boolean removeEvent (Event e){
            //return true if removal is successful, false otherwise
            //if returns -1 then event does not exist.

            int i = findEvent(e);
            if (i != -1) {
                events[i] = null;

                numEvents -= 1;
                return true;
            }

            return false;
        }

        public void dump () {
            //prints all events in the calendar.
            for (Event e : events) {
                if (e != null) {
                    System.out.println(e);

                }


            }

        }

    }




