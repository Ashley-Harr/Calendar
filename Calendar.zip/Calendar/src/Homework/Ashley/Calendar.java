package Homework.Ashley;

public class Calendar {

    private static final int MAXEVENTS = 4;
    private int numEvents;

    private Event[] events = new Event[MAXEVENTS];
    ;

    public Calendar(int numEvents, Event[] events) {
        this.numEvents = numEvents;
        this.events = events;
        numEvents = 0;

    }

    public boolean addEven(Event e) {


    }

    public int findEvent(Event e) {



    }

    public boolean removeEvent(Event e) {


    }

    public void dump() {


    }

}


