package Homework.Ashley;

public class Date {

    int day;
    int month;
    int year;



    public Date(int day, int month, int year) {
        this.day = day;
        this.month = month;
        this.year = year;


        if (day > 31 || day < 1) throw new IllegalArgumentException();

        if (month > 12 || month < 1) throw new IllegalArgumentException();

        if (year < 2020 || year > 2030) throw new IllegalArgumentException();

    }

    public int getDay() {
        return day;
    }

    public int getMonth() {
        return month;
    }

    public int getYear() {
        return year;
    }

    @Override
    public String toString() {
        return day +
                "/" + month +
                "/" + year;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Date date = (Date) o;
        return getDay() == date.getDay() &&
                getMonth() == date.getMonth() &&
                getYear() == date.getYear();
    }

    public int compareTo (Date otherDate) {
        //0 if equal to other date
        // -1 if before other date
        // +1 if after other date
        if (this.year == otherDate.year){
            if (this.month == otherDate.month){
                if (this.day == otherDate.day){
                    return 0;

                } else {
                    return this.day > otherDate.day ? 1 : -1;

                }


            } else {
                return this.month > otherDate.month ? 1 : -1;

            }


        } else {
            return this.year > otherDate.year ? 1 : -1;

        }



    }

}
