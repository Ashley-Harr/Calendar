package Homework.Ashley;

import java.util.Objects;

public class Event {

    Date date;
    int start;  //0-23
    int end;  //0-23
    String description; //description of even


    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Event event = (Event) o;
        return getStart() == event.getStart() &&
                getEnd() == event.getEnd() &&
                getDate().equals(event.getDate()) &&
                Objects.equals(getDescription(), event.getDescription());
    }

    @Override
    public String toString() {
        //“month/day/year start--end: description”.
        return
                date +
                " " + start +
                " --" + end +
                ": " + description;
    }

    public Event(Date date, int start, int end, String description) {
        this.date = date;
        this.start = start;
        this.end = end;
        this.description = description;


        if (start > 23 || start < 0) throw new IllegalArgumentException();
        if (end > 23 || end < 0) throw new IllegalArgumentException();


        if (start > end) throw new IllegalArgumentException();

    }

    public Date getDate() {
        return date;
    }

    public int getStart() {
        return start;
    }

    public int getEnd() {
        return end;
    }

    public String getDescription() {
        return description;
    }

}



